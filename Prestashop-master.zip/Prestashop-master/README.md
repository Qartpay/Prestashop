# Prestashop 1.7 and above
This plugin belongs to Qartpay payment gateway.

Download the Prestashop Qartpay Plugin.
Login to Prestashop admin.
Go to Modules from admin menu and click on UPLOAD A MODULE button, choose downloaded Qartpay.zip to upload there. Or you can also extract the downloaded folder (Qartpay.zip) and paste this folder (Qartpay) in Modules folder under prestashop root folder and then go to Modules from admin and click on Selection tab, find Qartpay module there, click on INSTALL button.

After finishing installation click on Configure button, edit and save the below configuration:
Merchant PAY ID- Test/Production Pay Id provided by Qartpay
Merchant SALT - SALT provided by Qartpay
Website - Copy and paste the complete Url including http or https.
Industry Type - As per your choice

Transaction URL

Test - https://dashboard.qartpay.com/crm/jsp/paymentrequest

Production - https://dashboard.qartpay.com/crm/jsp/paymentrequest


Qartpay is now installed for your website. You can start accepting payment through Qartpay.
